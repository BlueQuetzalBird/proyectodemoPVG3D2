using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Animations;

public class moving : MonoBehaviour
{
     private Vector3 pos;
     public float velocidad;
    public float extension;
    void Start()
{
 pos = this.transform.position;
}


 void Update()
{
float pos_x = extension * Mathf.Sin(2 * Mathf.PI * velocidad * Time.time);
        pos.x = pos_x;
this.transform.position = pos;
}
}